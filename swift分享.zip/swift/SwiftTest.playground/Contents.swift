//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//*******************  扩展  **********************

extension String {
    //do sth
}

//--------------添加计算属性---------------
extension Double {
    
    var km:Double {
        return self * 1000.0
    }
    
    var m:Double {
        return self
    }
    
    var cm:Double {
        return self / 100.0
    }
    
    
}

var a:Double = 10.0;
print(a.km,a.cm)

//----------------给值类型扩展新的构造器-----------------
//如果使用扩展给值类型添加一个构造器，如果该类型所有属性已经有默认值，但没有定制任何构造器，此时我们可以调用默认的构造器和成员逐一构造器。
struct Size {
    var width = 0.0
    var height = 0.0
}

struct Point {
    var x = 0.0
    var y = 0.0
}

struct Rect {
    var origin = Point()
    var size = Size()
}

// 这里因为Rect结构体都提供了属性的默认值，它可以自动会有一个默认的构造器和一个成员逐一的构造器，
let defaultRect = Rect() // 调用默认构造器
let memberwiseRect = Rect(origin: Point(x: 2.0, y: 2.0), size: Size(width: 5.0, height: 5.0))

// 下面我们给Rect扩展一个构造器
extension Rect {
    init(center: Point, size: Size) {
        let originX = center.x - size.width / 2.0
        let originY = center.y - size.height / 2.0
        
        // 调用本类自动得到的成员逐一构造器
        self.init(origin: Point(x: originX, y: originY), size: size)
    }  
}

//----------- 扩展方法 ------------------
extension Int {
    // 参数是一个单类型的闭包，没有参数，没有返回值的闭包
    func repetions(task: () -> ()) {
        for _ in 0...self {
            task()
        }
    }
    // 仅是例子，这是不好的设计
    static func multiply(a: Int, b: Int) -> Int {
        return a * b
    }
    
    // 要修改Self，就需要是可改类型方法，需要加上关键字mutating
    mutating func square() {
        self = self * self
    }
}

var number = 4
number.repetions {
    print("test extension")
}

print(number.square())
print(Int.multiply(2, b: 3))




//************  闭包 ****************
var tempstr:String {

get {
    return "test"
}

set {
    print("set ok")
}

}

var tempStr2:String = "testtest" {
    
willSet {
    print("newValue\(newValue)")
}

didSet {
    print("newValue\(oldValue)")
}

}

tempStr2 = "ccc"


//上面例子最全表现形式

/*
 
var tempString = {
    
    (arguments) -> returnType in
    code
    
}(argument)
 
*/

//完整表现形式
var aaaa = {
    
    (a:String,b:String) -> String in
    return a + b
    
}("www","cccc")
/*
* Swift中的闭包有很多优化的地方:
* (1)根据上下文推断参数和返回值类型(swift类型推断)
* (2)从单行表达式闭包中隐式返回（也就是闭包体只有一行代码，可以省略return）
* (3)可以使用简化参数名，如$0, $1(从0开始，表示第i个参数...)
* (4)提供了尾随闭包语法(Trailing closure syntax)
*/

//精简后
var aa = {
    $0 + $1
}("www","cccc")



//map函数
//可建立一个a数组的映射数组b，即数学上的 y = f(x)
func fx(x : Int) -> Int {
    return x + 10
}

var aArr = [1, 2, 3, 4, 5]
var bArr = aArr.map(fx)
print(bArr)

let numbers:NSArray = [1,2,3,4,5]



/*
 * 尾随闭包（Trailing Closures）
 * 如果函数需要一个闭包参数作为参数，且这个参数是最后一个参数，而这个闭包表达式又很长时，
 * 使用尾随闭包是很有用的。尾随闭包可以放在函数参数列表外，也就是括号外。如果函数只有一个参数，
 * 那么可以把括号()省略掉，后面直接跟着闭包。
 */

func calculate(opt:String,funcX:(Int,Int)->Int) -> Void{
    switch opt {
    case "+":
        print("2+1=\(funcX(2,1))")
    default:
        print("2-1=\(funcX(2,1))")
    }
}

calculate("+") { (a:Int,b:Int ) -> Int in
    a + b
}

calculate("+", funcX: {(a:Int,b:Int ) -> Int in a + b})



/* 捕获值
 * 闭包可以根据环境上下文捕获到定义的常量和变量。闭包可以引用和修改这些捕获到的常量和变量，
 * 就算在原来的范围内定义为常量或者变量已经不再存在。
 * 在Swift中闭包的最简单形式是嵌套函数。
 */
func increment(amount: Int) -> (() -> Int) {
    var total = 0
    func incrementAmount() -> Int {
        total += amount // total是外部函数体内的变量，这里是可以捕获到的
        return total
    }
    return incrementAmount // 返回的是一个嵌套函数（闭包）
}

// 闭包是引用类型，所以incrementByTen声明为常量也可以修改total
let incrementByTen = increment(10)
incrementByTen() // return 10,incrementByTen是一个闭包
// 这里是没有改变对increment的引用，所以会保存之前的值
incrementByTen() // return 20
incrementByTen() // return 30

let incrementByOne = increment(1)
incrementByOne() // return 1
incrementByOne() // return 2
incrementByTen() // return 40
incrementByOne() // return 3

protocol someProtocol {
    
}

class superAA {
    
}

class aaa: superAA,someProtocol {
    
}
